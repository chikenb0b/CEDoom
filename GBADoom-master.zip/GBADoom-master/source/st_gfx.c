#include "gfx/stbar.h"

#include "st_gfx.h"

const unsigned int gfx_stbar_len = sizeof(gfx_stbar);
