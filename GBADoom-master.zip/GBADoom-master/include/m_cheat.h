#ifndef M_CHEAT_H
#define M_CHEAT_H

#include "d_event.h"

boolean C_Responder (event_t *ev);


#endif // M_CHEAT_H
