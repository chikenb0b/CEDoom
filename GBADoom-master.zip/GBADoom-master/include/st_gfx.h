#ifndef ST_GFX_H
#define ST_GFX_H

extern const unsigned char gfx_stbar[];
extern const unsigned int gfx_stbar_len;

#endif // ST_GFX_H
