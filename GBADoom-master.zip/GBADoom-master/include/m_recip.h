#ifndef RECIP_H
#define RECIP_H

const extern unsigned int reciprocalTable[];

#endif // RECIP_H
