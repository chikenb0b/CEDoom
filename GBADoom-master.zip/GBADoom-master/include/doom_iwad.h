#ifndef DOOM_IWAD_H
#define DOOM_IWAD_H

extern const unsigned char doom_iwad[];
extern const unsigned int doom_iwad_len;

#endif // DOOM_IWAD_H
